from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.domain.models.campaign_model import CampaignStatus
from app.domain.schemas.campaign_schema import (
    CampaignActionResponse,
    CampaignCreate,
    CampaignDonationCreate,
    CampaignDonationResponse,
    CampaignDonationUpdateStatus,
    CampaignReject,
    CampaignResponse,
    CampaignResume,
    CampaignReview,
    CampaignSuspend,
    CampaignUpdate,
)
from app.services import campaign_service

router = APIRouter(prefix="/campaigns", tags=["Campaigns"])


@router.post("/", response_model=CampaignResponse, status_code=status.HTTP_201_CREATED)
async def create_campaign_endpoint(
    data: CampaignCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return await campaign_service.create_campaign(db, data,user_id=current_user["user_id"]  )


@router.get("/", response_model=list[CampaignResponse])
async def list_campaigns_endpoint(
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
    status: CampaignStatus | None = None,
    charity_id: UUID | None = None,
    category: str | None = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    return await campaign_service.get_campaigns(
        db=db,
        skip=skip,
        limit=limit,
        status=status,
        charity_id=charity_id,
        category=category,
    )


@router.get("/{campaign_id}", response_model=CampaignResponse)
async def get_campaign_endpoint(
    campaign_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return campaign


@router.patch("/{campaign_id}", response_model=CampaignResponse)
async def update_campaign_endpoint(
    campaign_id: UUID,
    data: CampaignUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.update_campaign(db, campaign, data)


@router.delete("/{campaign_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_campaign_endpoint(
    campaign_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    await campaign_service.delete_campaign(db, campaign)
    return None


@router.post("/{campaign_id}/submit", response_model=CampaignResponse)
async def submit_campaign_endpoint(
    campaign_id: UUID,
    actor_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.submit_campaign(db, campaign, actor_id)


@router.post("/{campaign_id}/approve", response_model=CampaignResponse)
async def approve_campaign_endpoint(
    campaign_id: UUID,
    data: CampaignReview,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.approve_campaign(db, campaign, data)


@router.post("/{campaign_id}/reject", response_model=CampaignResponse)
async def reject_campaign_endpoint(
    campaign_id: UUID,
    data: CampaignReject,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.reject_campaign(db, campaign, data)


@router.post("/{campaign_id}/suspend", response_model=CampaignResponse)
async def suspend_campaign_endpoint(
    campaign_id: UUID,
    data: CampaignSuspend,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.suspend_campaign(db, campaign, data)


@router.post("/{campaign_id}/resume", response_model=CampaignResponse)
async def resume_campaign_endpoint(
    campaign_id: UUID,
    data: CampaignResume,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.resume_campaign(db, campaign, data)


@router.post(
    "/donations",
    response_model=CampaignDonationResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_donation_endpoint(
    data: CampaignDonationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, data.campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    if campaign.status != CampaignStatus.ACTIVE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Campaign is not active",
        )

    return await campaign_service.create_donation(db, data)


@router.get(
    "/{campaign_id}/donations",
    response_model=list[CampaignDonationResponse],
)
async def list_campaign_donations_endpoint(
    campaign_id: UUID,
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.get_campaign_donations(
        db=db,
        campaign_id=campaign_id,
        skip=skip,
        limit=limit,
    )


@router.patch(
    "/donations/{donation_id}/status",
    response_model=CampaignDonationResponse,
)
async def update_donation_status_endpoint(
    donation_id: UUID,
    data: CampaignDonationUpdateStatus,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    donation = await campaign_service.get_donation(db, donation_id)

    if not donation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Donation not found",
        )

    return await campaign_service.update_donation_status(db, donation, data)


@router.get(
    "/{campaign_id}/actions",
    response_model=list[CampaignActionResponse],
)
async def list_campaign_actions_endpoint(
    campaign_id: UUID,
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    campaign = await campaign_service.get_campaign(db, campaign_id)

    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found",
        )

    return await campaign_service.get_campaign_actions(
        db=db,
        campaign_id=campaign_id,
        skip=skip,
        limit=limit,
    )
