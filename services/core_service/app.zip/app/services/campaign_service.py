from datetime import datetime
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.RegInstitute_model import CharityProfile
from app.domain.models.campaign_model import (
    Campaign,
    CampaignAction,
    CampaignActionType,
    CampaignDonation,
    CampaignDonationStatus,
    CampaignStatus,
)
from app.domain.schemas.campaign_schema import (
    CampaignCreate,
    CampaignUpdate,
    CampaignReview,
    CampaignReject,
    CampaignSuspend,
    CampaignResume,
    CampaignDonationCreate,
    CampaignDonationUpdateStatus,
)
from app.repository.campaign_repository import campaign_repository


async def create_campaign(
    db: AsyncSession,
    data: CampaignCreate,
    user_id: UUID,
):
    charity_profile = await charity_profile_repository.get_by_user_id(db, user_id)

    if not charity_profile:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only charity users can create campaigns",
        )

    payload = data.model_dump() if hasattr(data, "model_dump") else data.dict()

    payload["start_date"] = to_naive_utc(payload.get("start_date"))
    payload["end_date"] = to_naive_utc(payload.get("end_date"))

    campaign = Campaign(
        **payload,
        charity_id=charity_profile.id,
        status=CampaignStatus.DRAFT,
    )

    return await campaign_repository.create(db, campaign)


async def get_campaign(
    db: AsyncSession,
    campaign_id: UUID,
) -> Campaign | None:
    return await campaign_repository.get_by_id(db, campaign_id)


async def get_campaigns(
    db: AsyncSession,
    skip: int = 0,
    limit: int = 20,
    status: CampaignStatus | None = None,
    charity_id: UUID | None = None,
    category: str | None = None,
) -> list[Campaign]:
    return await campaign_repository.get_campaigns(
        db=db,
        skip=skip,
        limit=limit,
        status=status,
        charity_id=charity_id,
        category=category,
    )


async def update_campaign(
    db: AsyncSession,
    campaign: Campaign,
    data: CampaignUpdate,
) -> Campaign:
    update_data = data.model_dump(exclude_unset=True)

    return await campaign_repository.update(
        db=db,
        campaign=campaign,
        update_data=update_data,
    )


async def delete_campaign(
    db: AsyncSession,
    campaign: Campaign,
) -> None:
    await campaign_repository.delete(db, campaign)


async def submit_campaign(
    db: AsyncSession,
    campaign: Campaign,
    actor_id: UUID,
) -> Campaign:
    campaign.status = CampaignStatus.PENDING_REVIEW

    action = CampaignAction(
        campaign_id=campaign.id,
        actor_id=actor_id,
        action=CampaignActionType.SUBMITTED,
    )

    await campaign_repository.create_action(db, action)
    await db.refresh(campaign)

    return campaign


async def approve_campaign(
    db: AsyncSession,
    campaign: Campaign,
    data: CampaignReview,
) -> Campaign:
    campaign.status = CampaignStatus.ACTIVE
    campaign.reviewed_by = data.reviewed_by
    campaign.reviewed_at = datetime.utcnow()
    campaign.review_note = data.review_note

    action = CampaignAction(
        campaign_id=campaign.id,
        actor_id=data.reviewed_by,
        action=CampaignActionType.APPROVED,
        reason=data.review_note,
    )

    await campaign_repository.create_action(db, action)
    await db.refresh(campaign)

    return campaign


async def reject_campaign(
    db: AsyncSession,
    campaign: Campaign,
    data: CampaignReject,
) -> Campaign:
    campaign.status = CampaignStatus.REJECTED
    campaign.reviewed_by = data.reviewed_by
    campaign.reviewed_at = datetime.utcnow()
    campaign.review_note = data.review_note

    action = CampaignAction(
        campaign_id=campaign.id,
        actor_id=data.reviewed_by,
        action=CampaignActionType.REJECTED,
        reason=data.review_note,
    )

    await campaign_repository.create_action(db, action)
    await db.refresh(campaign)

    return campaign


async def suspend_campaign(
    db: AsyncSession,
    campaign: Campaign,
    data: CampaignSuspend,
) -> Campaign:
    campaign.status = CampaignStatus.SUSPENDED
    campaign.suspended_by = data.suspended_by
    campaign.suspended_at = datetime.utcnow()
    campaign.suspension_reason = data.suspension_reason

    action = CampaignAction(
        campaign_id=campaign.id,
        actor_id=data.suspended_by,
        action=CampaignActionType.SUSPENDED,
        reason=data.suspension_reason,
    )

    await campaign_repository.create_action(db, action)
    await db.refresh(campaign)

    return campaign


async def resume_campaign(
    db: AsyncSession,
    campaign: Campaign,
    data: CampaignResume,
) -> Campaign:
    campaign.status = CampaignStatus.ACTIVE
    campaign.suspended_by = None
    campaign.suspended_at = None
    campaign.suspension_reason = None

    action = CampaignAction(
        campaign_id=campaign.id,
        actor_id=data.actor_id,
        action=CampaignActionType.RESUMED,
        reason=data.reason,
    )

    await campaign_repository.create_action(db, action)
    await db.refresh(campaign)

    return campaign


async def create_donation(
    db: AsyncSession,
    data: CampaignDonationCreate,
) -> CampaignDonation:
    donation = CampaignDonation(**data.model_dump())

    return await campaign_repository.create_donation(
        db=db,
        donation=donation,
    )


async def get_donation(
    db: AsyncSession,
    donation_id: UUID,
) -> CampaignDonation | None:
    return await campaign_repository.get_donation_by_id(
        db=db,
        donation_id=donation_id,
    )


async def get_campaign_donations(
    db: AsyncSession,
    campaign_id: UUID,
    skip: int = 0,
    limit: int = 20,
) -> list[CampaignDonation]:
    return await campaign_repository.get_campaign_donations(
        db=db,
        campaign_id=campaign_id,
        skip=skip,
        limit=limit,
    )


async def update_donation_status(
    db: AsyncSession,
    donation: CampaignDonation,
    data: CampaignDonationUpdateStatus,
) -> CampaignDonation:
    previous_status = donation.status

    donation.status = data.status

    if data.payment_ref:
        donation.payment_ref = data.payment_ref

    if data.status == CampaignDonationStatus.PAID:
        donation.paid_at = datetime.utcnow()

        if previous_status != CampaignDonationStatus.PAID:
            campaign = await campaign_repository.get_by_id(
                db=db,
                campaign_id=donation.campaign_id,
            )

            if campaign:
                campaign.collected_amount += donation.amount

    return await campaign_repository.update_donation(
        db=db,
        donation=donation,
    )


async def get_campaign_actions(
    db: AsyncSession,
    campaign_id: UUID,
    skip: int = 0,
    limit: int = 50,
) -> list[CampaignAction]:
    return await campaign_repository.get_actions(
        db=db,
        campaign_id=campaign_id,
        skip=skip,
        limit=limit,
    )

from datetime import datetime, timezone


def to_naive_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None

    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)

    return value
