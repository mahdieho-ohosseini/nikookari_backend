from datetime import datetime, timezone
from typing import Optional, List
from uuid import UUID

from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.RegInstitute_model import CharityProfile
from app.domain.models.campaign_model import (
    Campaign,
    CampaignAction,
    CampaignDonation,
    CampaignStatus,
)


class CampaignRepository:
    # --- Campaign Methods ---

    async def get_by_id(
        self,
        db: AsyncSession,
        campaign_id: UUID,
    ) -> Optional[Campaign]:
        result = await db.execute(
            select(Campaign).where(Campaign.id == campaign_id)
        )
        return result.scalar_one_or_none()

    async def get_campaigns(
        self,
        db: AsyncSession,
        skip: int = 0,
        limit: int = 20,
        status: Optional[CampaignStatus] = None,
        charity_id: Optional[UUID] = None,
        category: Optional[str] = None,
    ) -> List[Campaign]:
        stmt = select(Campaign)

        if status:
            stmt = stmt.where(Campaign.status == status)
        if charity_id:
            stmt = stmt.where(Campaign.charity_id == charity_id)
        if category:
            stmt = stmt.where(Campaign.category == category)

        stmt = stmt.order_by(desc(Campaign.created_at)).offset(skip).limit(limit)
        
        result = await db.execute(stmt)
        return list(result.scalars().all())

    async def create(
        self,
        db: AsyncSession,
        campaign: Campaign,
    ) -> Campaign:
        db.add(campaign)
        await db.flush()
        await db.refresh(campaign)
        return campaign

    async def update(
        self,
        db: AsyncSession,
        campaign: Campaign,
        update_data: dict,
    ) -> Campaign:
        for key, value in update_data.items():
            setattr(campaign, key, value)

        await db.flush()
        await db.refresh(campaign)
        return campaign

    async def delete(self, db: AsyncSession, campaign: Campaign) -> None:
        await db.delete(campaign)
        await db.flush()

    # --- Campaign Action Methods (برای لاگ تغییرات و تاییدیه ها) ---

    async def create_action(
        self,
        db: AsyncSession,
        action: CampaignAction,
    ) -> CampaignAction:
        db.add(action)
        await db.flush()
        await db.refresh(action)
        return action

    async def get_actions(
        self,
        db: AsyncSession,
        campaign_id: UUID,
        skip: int = 0,
        limit: int = 50,
    ) -> List[CampaignAction]:
        result = await db.execute(
            select(CampaignAction)
            .where(CampaignAction.campaign_id == campaign_id)
            .order_by(desc(CampaignAction.created_at))
            .offset(skip)
            .limit(limit)
        )
        return list(result.scalars().all())

    # --- Donation Methods ---

    async def create_donation(
        self,
        db: AsyncSession,
        donation: CampaignDonation,
    ) -> CampaignDonation:
        db.add(donation)
        await db.flush()
        await db.refresh(donation)
        return donation

    async def get_donation_by_id(
        self,
        db: AsyncSession,
        donation_id: UUID,
    ) -> Optional[CampaignDonation]:
        result = await db.execute(
            select(CampaignDonation).where(CampaignDonation.id == donation_id)
        )
        return result.scalar_one_or_none()

    async def get_campaign_donations(
        self,
        db: AsyncSession,
        campaign_id: UUID,
        skip: int = 0,
        limit: int = 20,
    ) -> List[CampaignDonation]:
        result = await db.execute(
            select(CampaignDonation)
            .where(CampaignDonation.campaign_id == campaign_id)
            .order_by(desc(CampaignDonation.created_at))
            .offset(skip)
            .limit(limit)
        )
        return list(result.scalars().all())

    async def update_donation(
        self,
        db: AsyncSession,
        donation: CampaignDonation,
    ) -> CampaignDonation:
        await db.flush()
        await db.refresh(donation)
        return donation

async def get_by_user_id(db: AsyncSession, user_id: UUID):
    result = await db.execute(
        select(CharityProfile).where(CharityProfile.user_id == user_id)
    )
    return result.scalar_one_or_none()



campaign_repository = CampaignRepository()
