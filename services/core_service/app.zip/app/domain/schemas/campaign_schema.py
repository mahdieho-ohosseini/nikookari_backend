from datetime import datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict

from app.domain.models.campaign_model import (
    CampaignStatus,
    CampaignDonationStatus,
    CampaignActionType,
)


class CampaignBase(BaseModel):
    title: str = Field(..., max_length=255)
    category: str = Field(..., max_length=100)
    short_description: str = Field(..., max_length=500)
    target_amount: Decimal = Field(..., gt=0)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None


class CampaignCreate(CampaignBase):
    description: str


class CampaignUpdate(BaseModel):
    title: Optional[str] = Field(default=None, max_length=255)
    category: Optional[str] = Field(default=None, max_length=100)
    description: Optional[str] = None
    short_description: Optional[str] = Field(default=None, max_length=500)
    target_amount: Optional[Decimal] = Field(default=None, gt=0)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None


class CampaignReview(BaseModel):
    reviewed_by: UUID
    review_note: Optional[str] = None


class CampaignReject(BaseModel):
    reviewed_by: UUID
    review_note: str


class CampaignSuspend(BaseModel):
    suspended_by: UUID
    suspension_reason: str


class CampaignResume(BaseModel):
    actor_id: UUID
    reason: Optional[str] = None


class CampaignResponse(CampaignBase):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    charity_id: UUID
    collected_amount: Decimal
    status: CampaignStatus

    reviewed_by: Optional[UUID] = None
    reviewed_at: Optional[datetime] = None
    review_note: Optional[str] = None

    suspended_by: Optional[UUID] = None
    suspended_at: Optional[datetime] = None
    suspension_reason: Optional[str] = None

    created_at: datetime
    updated_at: datetime


class CampaignDonationCreate(BaseModel):
    campaign_id: UUID
    donor_id: Optional[UUID] = None
    amount: Decimal = Field(..., gt=0)
    payment_ref: Optional[str] = Field(default=None, max_length=255)


class CampaignDonationUpdateStatus(BaseModel):
    status: CampaignDonationStatus
    payment_ref: Optional[str] = None


class CampaignDonationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    campaign_id: UUID
    donor_id: Optional[UUID] = None
    amount: Decimal
    status: CampaignDonationStatus
    payment_ref: Optional[str] = None
    paid_at: Optional[datetime] = None
    created_at: datetime


class CampaignActionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    campaign_id: UUID
    actor_id: UUID
    action: CampaignActionType
    reason: Optional[str] = None
    created_at: datetime
